import os
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
from backend import registrar_usuario

class RegistroForm:
    def __init__(self, master):
        self.master = master
        self.form = tk.Toplevel(master)
        self.form.title("Registro")

        # Configuración de la forma redondeada
        self.form.overrideredirect(True)
        self.form.attributes("-alpha", 0.95)

        # Obtener las dimensiones de la pantalla
        screen_width = self.form.winfo_screenwidth()
        screen_height = self.form.winfo_screenheight()

        # Tamaño del formulario
        form_width = 1366
        form_height = 720

        # Calcular la posición central del formulario
        x_position = (screen_width - form_width) // 2
        y_position = (screen_height - form_height) // 2

        # Establecer la geometría del formulario
        self.form.geometry(f"{form_width}x{form_height}+{x_position}+{y_position}")
        self.form.configure(bg="#FF8C00")

        # Agregar etiqueta (Label) con la imagen de la "x" para cerrar la aplicación o cancelar el registro
        cerrar_image = Image.open("cerrar.png")  # Reemplazar con la ruta correcta de tu icono de cierre
        cerrar_image = cerrar_image.resize((20, 20), Image.ANTIALIAS)
        cerrar_icon = ImageTk.PhotoImage(cerrar_image)

        self.label_cerrar = ttk.Label(self.form, image=cerrar_icon, cursor="hand2", background='red')
        self.label_cerrar.image = cerrar_icon
        self.label_cerrar.place(relx=1.0, rely=0, anchor='ne')

        self.label_cerrar.bind("<Button-1>", self.cerrar_aplicacion)
        
        # Obtén la ruta del script actual y construye la ruta completa a la imagen
        script_dir = os.path.dirname(os.path.realpath(__file__))
        imagen_path = os.path.join(script_dir, "resources", "img", "galletica1.png")

        # Cargar una imagen PNG
        imagen = Image.open(imagen_path)
        imagen = imagen.resize((100, 100), Image.ANTIALIAS)

        # Crear un widget de etiqueta para mostrar la imagen a la derecha del formulario
        etiqueta_imagen = tk.Label(self.form, image=ImageTk.PhotoImage(imagen), bg="#FF8C00")
        etiqueta_imagen.grid(row=0, column=1, rowspan=5, padx=20, pady=20)

        font_style = ("Poppins", 12)
        self.etiqueta_nombre = tk.Label(self.form, text="Nombre", bg="#FF8C00", fg="white", font=font_style)
        self.entry_nombre = tk.Entry(self.form, bg="white", fg="black", font=font_style, relief=tk.FLAT, justify="center")
        self.etiqueta_correo = tk.Label(self.form, text="Correo Electrónico", bg="#FF8C00", fg="white", font=font_style)
        self.entry_correo = tk.Entry(self.form, bg="white", fg="black", font=font_style, relief=tk.FLAT, justify="center")
        self.etiqueta_contrasena = tk.Label(self.form, text="Contraseña", bg="#FF8C00", fg="white", font=font_style)
        self.entry_contrasena = tk.Entry(self.form, show="*", bg="white", fg="black", font=font_style, relief=tk.FLAT, justify="center")
        self.etiqueta_verificar_contrasena = tk.Label(self.form, text="Verificar Contraseña", bg="#FF8C00", fg="white", font=font_style)
        self.entry_verificar_contrasena = tk.Entry(self.form, show="*", bg="white", fg="black", font=font_style, relief=tk.FLAT, justify="center")

        # Colocar los elementos en la ventana
        self.etiqueta_nombre.grid(row=0, column=2, padx=10, pady=5)
        self.entry_nombre.grid(row=0, column=3, padx=10, pady=5)
        self.etiqueta_correo.grid(row=1, column=2, padx=10, pady=5)
        self.entry_correo.grid(row=1, column=3, padx=10, pady=5)
        self.etiqueta_contrasena.grid(row=2, column=2, padx=10, pady=5)
        self.entry_contrasena.grid(row=2, column=3, padx=10, pady=5)
        self.etiqueta_verificar_contrasena.grid(row=3, column=2, padx=10, pady=5)
        self.entry_verificar_contrasena.grid(row=3, column=3, padx=10, pady=5)

        # Cambiar la apariencia del botón "Registrar"
        boton_registrar = ttk.Button(self.form, text="Registrar", command=self.registrar, style='TButton')
        estilo_boton = ttk.Style()
        estilo_boton.configure('TButton', font=font_style, background='#FF8C00', foreground='black', borderwidth=5, focuscolor='#FF8C00')

        boton_registrar.grid(row=4, column=3, pady=10)

    def registrar(self):
        nombre = self.entry_nombre.get()
        correo = self.entry_correo.get()
        contrasena = self.entry_contrasena.get()
        verificar_contrasena = self.entry_verificar_contrasena.get()

        if not nombre or not correo or not contrasena or not verificar_contrasena:
            messagebox.showerror("Error", "Todos los campos son obligatorios.")
        elif contrasena != verificar_contrasena:
            messagebox.showerror("Error", "Las contraseñas no coinciden.")
        else:
            if registrar_usuario(nombre, correo, contrasena):
                messagebox.showinfo("Registro", "¡Registro exitoso!")
            else:
                messagebox.showerror("Error", "El correo ya está registrado.")

    def cerrar_aplicacion(self, event):
        # Cierra la aplicación
        self.master.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    registro_form = RegistroForm(root)
    root.mainloop()
