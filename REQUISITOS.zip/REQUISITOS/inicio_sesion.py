import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
from backend import verificar_credenciales

class InicioSesionForm:
    def __init__(self, master):
        self.master = master
        self.form = tk.Toplevel(master)
        self.form.title("Inicio de Sesión")

        # Configuración de la forma redondeada
        self.form.overrideredirect(True)
        self.form.attributes("-alpha", 0.95)

        # Obtener las dimensiones de la pantalla
        screen_width = self.form.winfo_screenwidth()
        screen_height = self.form.winfo_screenheight()

        # Tamaño del formulario
        form_width = 600
        form_height = 400

        # Calcular la posición central del formulario
        x_position = (screen_width - form_width) // 2
        y_position = (screen_height - form_height) // 2

        # Establecer la geometría del formulario
        self.form.geometry(f"{form_width}x{form_height}+{x_position}+{y_position}")
        self.form.configure(bg="#FF8C00")

        font_style = ("Poppins", 12)
        self.etiqueta_correo = tk.Label(self.form, text="Correo Electrónico", bg="#FF8C00", fg="white", font=font_style)
        self.entry_correo = tk.Entry(self.form, bg="white", fg="black", font=font_style, relief=tk.FLAT, justify="center")
        self.etiqueta_contrasena = tk.Label(self.form, text="Contraseña", bg="#FF8C00", fg="white", font=font_style)
        self.entry_contrasena = tk.Entry(self.form, show="*", bg="white", fg="black", font=font_style, relief=tk.FLAT, justify="center")

        self.boton_iniciar_sesion = tk.Button(self.form, text="Iniciar Sesión", command=self.iniciar_sesion, bg="white", fg="#FF8C00", font=font_style, relief=tk.FLAT)
        self.boton_volver = tk.Button(self.form, text="Volver", command=self.cerrar_ventana, bg="white", fg="#FF8C00", font=font_style, relief=tk.FLAT)

        # Colocar los elementos en la ventana
        self.etiqueta_correo.grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.entry_correo.grid(row=0, column=1, padx=10, pady=5, sticky="e")
        self.etiqueta_contrasena.grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.entry_contrasena.grid(row=1, column=1, padx=10, pady=5, sticky="e")
        self.boton_iniciar_sesion.grid(row=2, column=1, pady=10)
        self.boton_volver.grid(row=3, column=1, pady=10)

    def iniciar_sesion(self):
        correo = self.entry_correo.get()
        contrasena = self.entry_contrasena.get()

        if not correo or not contrasena:
            messagebox.showerror("Error", "Todos los campos son obligatorios.")
        elif verificar_credenciales(correo, contrasena):
            messagebox.showinfo("Iniciar Sesión", "¡Inicio de sesión exitoso!")
        else:
            messagebox.showerror("Error", "Credenciales incorrectas.")

    def cerrar_ventana(self):
        # Cierra la ventana actual
        self.form.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    inicio_sesion_form = InicioSesionForm(root)
    root.mainloop()
