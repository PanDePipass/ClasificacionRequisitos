import tkinter as tk
from tkinter import ttk, messagebox
from registro import RegistroForm
from inicio_sesion import InicioSesionForm  # Importa la clase InicioSesionForm desde el archivo inicio_sesion.py

class MainForm:
    def __init__(self, master):
        self.master = master
        self.master.title("Main Application")

        # Configuración de la forma redondeada
        self.master.overrideredirect(True)
        self.master.attributes("-alpha", 0.95)

        # Obtener las dimensiones de la pantalla
        screen_width = self.master.winfo_screenwidth()
        screen_height = self.master.winfo_screenheight()

        # Calcular la posición central
        x_position = (screen_width - 1366) // 2
        y_position = (screen_height - 720) // 2

        # Establecer la geometría de la ventana
        self.master.geometry(f"1366x720+{x_position}+{y_position}")
        self.master.configure(bg="#FF8C00")

        # Agregar botones para abrir la ventana de registro, iniciar sesión y cerrar la ventana principal
        self.boton_registro = ttk.Button(self.master, text="Registro", command=self.abrir_registro, style='TButton')
        self.boton_inicio_sesion = ttk.Button(self.master, text="Iniciar Sesión", command=self.abrir_inicio_sesion, style='TButton')  # Cambié la función a abrir_inicio_sesion
        self.boton_cerrar = ttk.Button(self.master, text="Cerrar", command=self.cerrar_ventana, style='TButton')

        estilo_boton = ttk.Style()
        estilo_boton.configure('TButton', font=("Poppins", 14), background='#FF8C00', foreground='black', borderwidth=5, focuscolor='#FF8C00')

        self.boton_registro.pack(pady=20)
        self.boton_inicio_sesion.pack(pady=20)
        self.boton_cerrar.pack(pady=20)

    def abrir_registro(self):
        # Abre la ventana de registro
        registro_form = RegistroForm(self.master)

    def abrir_inicio_sesion(self):
        # Abre la ventana de inicio de sesión
        inicio_sesion_form = InicioSesionForm(self.master)

    def cerrar_ventana(self):
        # Cierra la ventana principal
        self.master.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    main_form = MainForm(root)
    root.mainloop()
