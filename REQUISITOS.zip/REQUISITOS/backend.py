import json

def cargar_usuarios():
    try:
        with open("usuarios.json", "r") as file:
            usuarios = json.load(file)
    except FileNotFoundError:
        usuarios = []
    
    return usuarios

def guardar_usuarios(usuarios):
    with open("usuarios.json", "w") as file:
        json.dump(usuarios, file, indent=2)

def registrar_usuario(nombre, correo, contrasena):
    usuarios = cargar_usuarios()

    for usuario in usuarios:
        if usuario["correo"] == correo:
            return False  # El correo ya está registrado
    
    nuevo_usuario = {
        "nombre": nombre,
        "correo": correo,
        "contrasena": contrasena
    }

    usuarios.append(nuevo_usuario)
    guardar_usuarios(usuarios)
    return True  # Registro exitoso

def verificar_credenciales(correo, contrasena):
    usuarios = cargar_usuarios()

    for usuario in usuarios:
        if usuario["correo"] == correo and usuario["contrasena"] == contrasena:
            return True  # Credenciales válidas
    
    return False  # Credenciales inválidas
